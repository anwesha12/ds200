import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe
df=pd.read_csv(sys.argv[1], header=0)

#plot line plot with first column of dataframe as x values and second column as y values
plt.plot(df['Year of  expiry'],df['No. of  Leases'],color='#dd12dd',label="no of leases")
plt.plot(df['Year of  expiry'],df['Lease area (Hect.)'],color='#ff567e',label="lease area in Hect")

# plt.scatter(Mem['col3'],Mem['col4'],color='#caabdd',label="Hop6")

#specifying labels
plt.xlabel("x-label")
plt.ylabel("y-label")

#enable legend
plt.legend()
plt.show()
